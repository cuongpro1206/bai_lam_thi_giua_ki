package THI_GIUA_KI;

import java.util.Scanner;

/*
 Tạo lớp chương trình khai báo mảng một chiều A chứa các giá trị số nguyên có độ dài N (Nhập vào từ bàn phím)

- Viết hàm Nhập và hiển thị các giá trị trong mảng A? (1đ)

- Viết hàm đếm trong mảng A có bao nhiêu giá trị chia hết cho 5 mà không chia hết cho 6? (2đ)

- Viết hàm đếm số phần tử trong mảng A có giá trị lẻ? (1đ)

- Viết hàm đếm xem có bao nhiêu phần tử trong mảng A có giá trị lớn hơn hoặc bằng giá trị trung bình của tất cả các giá trị trong mảng A. (1đ)

- Viết hàm tách tất cả các giá trị lẻ trong mảng A vào mảng C (Chứa các giá trị lẻ). (1đ)

- Viết hàm kiếm tra xem trong mảng A có tồn tại phần tử nào xuất hiện lặp lại hay không? (1đ)
 */
public class CAU_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap so phan tu trong mang: ");
        int n = sc.nextInt();
        int[] A = new int[n];

//Viết hàm Nhập và hiển thị các giá trị trong mảng A? (1đ)
        for (int i = 0; i < n; i++) {
            System.out.print("Nhập phần tử thứ " + i + " : ");
            A[i] = sc.nextInt();
        }
        System.out.println("\nMảng ban đầu: ");
        for (int i = 0; i < n; i++) {
            System.out.print(A[i] + "\t");
        }

        //   Viết hàm đếm trong mảng A có bao nhiêu giá trị chia hết cho 5 mà không chia hết cho 6?
        int dem = 0;
        for (int i = 0; i < n; i++) {
            if (A[i] % 5 == 0 && A[i] % 6 != 0) {
                dem++;
            }
        }
        System.out.println("\n Co " + dem + " gia tri chia hết cho 5 mà không chia hết cho 6");

        //  Viết hàm đếm số phần tử trong mảng A có giá trị lẻ?
        int D = 0;
        for (int i = 0; i < n; i++) {
            if (A[i] % 2 == 1) {
                D++;
            }
        }
        System.out.println("Co " + D + " so le trong mang");

        //Viết hàm đếm xem có bao nhiêu phần tử trong mảng A có giá trị lớn hơn hoặc bằng giá trị trung bình của tất cả các giá trị trong mảng A.
        int tong = 0;
        int TB = 0;
        for (int i = 0; i < n; i++) {
            tong += A[i];
        }
        TB = tong / n;
        int Dem = 0;
        for (int i = 0; i < n; i++) {
            if (A[i] >= TB) {
                Dem++;
            }
        }
        System.out.println("Co " + Dem + " phần tử trong mảng A có giá trị lớn hơn hoặc bằng giá trị trung bình");

        //Viết hàm tách tất cả các giá trị lẻ trong mảng A vào mảng C (Chứa các giá trị lẻ).
        int j = 0;
        int[] C = new int[n];
        for (int i = 0; i < n; i++) {
            if (A[i] % 2 == 1) {
                C[j] = A[i];
                j++;
            }
        }
        System.out.println("Các phần tử của mảng C  là: ");
        for (int i = 0; i < j; i++) {
            System.out.print(C[i] + "\t");
        }

        //Viết hàm kiếm tra xem trong mảng A có tồn tại phần tử nào xuất hiện lặp lại hay không?
        int a = 0;
        System.out.print("\nNhap so can kiem tra : ");
        int X = sc.nextInt();
        for (int i = 0; i < n; i++) {
            if (A[i] == X) {
                a++;
            }
        }
        if (a >= 2) {
            System.out.println("Co ton tai gia tri " + X + " lap lai trong mang.");
        } else {
            System.out.println("Khong ton tai gia tri " + X +" lap lai trong mang.");
        }
    }
}
