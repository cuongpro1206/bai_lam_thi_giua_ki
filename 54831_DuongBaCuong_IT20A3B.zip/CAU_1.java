package THI_GIUA_KI;

import java.util.Scanner;

//Tạo lớp chương trình nhập một số nguyên n từ bàn phím (yêu cầu n phải lớn hơn 2) và hiển thị đây là số chẵn hay là số lẽ. (2đ)
public class CAU_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap n :");
        int n = sc.nextInt();
        if (n >2) {
            if (n % 2 == 0) {
                System.out.println(n + " la so chan.");
            } else {
                System.out.println(n + "la so le.");
            }
        }
    }
}
